import java.util.*;

// Student interface
interface Student {
    void register();
    void unregister();
}

// Generic class for a student with a specific type of ID
class StudentImpl<T> implements Student {
    T id;

    public StudentImpl(T id) {
        this.id = id;
    }

    public void register() {
        System.out.println("Student with ID " + id + " is registered.");
    }

    public void unregister() {
        System.out.println("Student with ID " + id + " is unregistered.");
    }
}

public class StudentRegistration {
    // Generic List of students using the Student interface
    List<Student> students = new ArrayList<>();

    public void registerStudent(Student student) {
        students.add(student);
    }

    public void unregisterStudent(Student student) {
        students.remove(student);
    }

    public static void main(String[] args) {
        // Create a new student registration system
        StudentRegistration regSystem = new StudentRegistration();

        // Register some students with different ID types (String, Integer, etc.)
        regSystem.registerStudent(new StudentImpl<>("20200305034"));
        regSystem.registerStudent(new StudentImpl<>(123456));
        regSystem.registerStudent(new StudentImpl<>(UUID.randomUUID()));

        // Use a lambda function to print out all registered students
        regSystem.students.forEach(student -> student.register());

        // Unregister a student
        regSystem.unregisterStudent(new StudentImpl<>(123456));

        // Print out all registered students again
        regSystem.students.forEach(student -> student.register());
    }
}
